/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical7mnogopotok;

/**
 *
 * @author М_З_А
 */
public class Thread1 extends Thread{
    private boolean stop = false;
    Running run = new Running();

    public synchronized void printCurrentThreadName() {
        System.out.println("Привет из потока " + Thread.currentThread().getName());
    }
    public void stopThread() {
        stop = true;
        run.shutdown();
    }

    @Override
    public void run() {
        while (!stop && run.isRunning()) {
            printCurrentThreadName();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        }
    }
}

