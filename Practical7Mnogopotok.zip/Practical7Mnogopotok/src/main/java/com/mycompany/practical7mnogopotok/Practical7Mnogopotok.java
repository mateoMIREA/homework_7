/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical7mnogopotok;

import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Practical7Mnogopotok {
    private boolean stop=false;
    public static void main(String[] args) throws Exception {
        System.out.println("Практика №7, Вариант 4, Новиков М.С., РИБО-01-21, для остановки выполнения программы нажмите любую клавишу...");
        Thread thread1 = new Thread1();
        Thread thread2 = new Thread1();
        thread1.start();
        thread2.start();
        
        Running run = new Running();
        run.shutdown();
        Scanner sc = new Scanner(System.in);
        sc.nextLine();

    ((Thread1) thread1).stopThread();
    ((Thread1) thread2).stopThread();
    }
}
