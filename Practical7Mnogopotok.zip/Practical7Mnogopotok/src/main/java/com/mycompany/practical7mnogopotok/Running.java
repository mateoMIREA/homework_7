/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical7mnogopotok;

/**
 *
 * @author М_З_А
 */
public class Running {
    private volatile boolean running = true;

    public Running() {
    }

    public boolean isRunning() {
        return running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }
    
    public void shutdown(){
        this.running = false;
    }
}
